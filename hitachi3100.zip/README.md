# Hitachi 3100 자동 분석기 제어 및 임상화학 시스템

Hitachi Automatic Analyzer 3100 의 **Host 통신(매뉴얼 Chapter 15, RS-232C)** 을 기준으로 오더 전송/결과 수신, 정도관리(QC), 시약 잔량, 검사 이력을 관리하는 Java 21 Swing 프로그램입니다.

## 실행

```cmd
build_and_run.bat        :: 컴파일 + 실행
run_tests.bat            :: 통합 테스트 17개 실행 (외부 라이브러리 불필요)
```

* 처음에는 **내장 시뮬레이터**(AU 절차를 매뉴얼대로 흉내 냄)에 자동 연결됩니다.
* 실제 장비: 상단 통신 모드에서 `RS-232C COMx` 선택. **`lib\jSerialComm-2.x.jar` 를 넣어야** 포트가 열립니다.
  (없으면 "연결된 척" 하지 않고 오류를 표시합니다.) 직렬-이더넷 변환기는 포트 이름을 `192.168.0.10:4001` 형식으로 지정하는 TCP 방식도 코드에 있습니다.
* 통신 파라미터는 장비의 `[Menu]→[Parameters]→[System]→[Com. Parameters]` 와 같아야 합니다. 기본값 7bit / 짝수 패리티 / 2 stop / 9600bps /
  종료 코드 **ETX+BCC**. 다르면 `data/serial.properties` 로 지정하세요 (`data/*.sample` 참고).
* 장비의 Test Code(채널 번호)가 기본값(AST=1 … IMA=17)과 다르면 `data/channel_map.properties` 로 지정하세요.

## 통신 동작 방식 (매뉴얼 15.1.4 기준)

| 상황 | Host 동작 |
|---|---|
| AU 가 `ANY` 전송 | 최소 100ms 후 응답: Batch 전송 요청된 Routine 오더가 있으면 `SPE`(TS 지시), 없으면 `MOR` |
| AU 가 `SPE`(TS 문의) 전송 | 해당 오더가 있으면 문의의 Sample Information 을 그대로 실어 `SPE` 로 응답, 없으면 `MOR` |
| AU 가 결과(`FR1`/`FR2`/`END`) 전송 | BCC·형식 검사 후 정상이면 `MOR`, 이상이면 `REP` (연속 3회면 경고) |
| AU 가 `REP` 전송 | 마지막 송신 텍스트 재전송 |
| 같은 결과 텍스트 재수신 | 처리하지 않고 `MOR` 만 응답 (이력/시약 중복 방지) |

* **Routine**: "오더 전송" → Batch 로 전달 + AU 실시간 문의에도 응답. **Stat**: 매뉴얼상 Batch 불가 → AU 문의 시에만 전달.
* **Control / Calibration 은 Host 가 오더할 수 없습니다.** QC 는 장비가 보낸 결과의 Function Character(`f`)와 Control No.(1~5 → QC1~QC5)로 분류합니다. ID 문자열로 추정하지 않습니다.
* Data Alarm 문자(매뉴얼 15.1.10)는 `H`/`L` 이 High/Low 가 아닙니다. High/Low 는 참고치로 Host 가 판정하고, 알람은 별도 표시합니다.
* 측정 **시작은 장비**(Start Conditions)에서 합니다. 이 프로그램은 TS(검사 항목)를 전달합니다.

## 이번 수정 내역

**통신/프로토콜**: 폴링 절차 구현(ANY→MOR/SPE), 응답 지연 ≥100ms, BCC·길이·문자범위 검사 후 REP, 바이트 스트림 프레임 조립(분할/연속/잡음 처리),
REP 수신 시 재전송, 중복 결과 무시, 링크 무응답 감시, TS 지시 88바이트/문의 43바이트 규격, 실제 시리얼 포트 열기(jSerialComm 리플렉션), FU 기반 샘플 종류 판별, 시뮬레이터를 AU 절차대로 재작성

**업무 로직**: QC 판별을 ID 문자열→Function Character 로 변경, 오더 검증(Position 1~35, ID 13자·ASCII, 중복 Position/ID 거부), 정확한 결과 매칭(OR 조건 제거),
이미 전송된 오더 재전송 방지, 결과 대기 시간 초과 시 ERROR 상태, 값 없음(NaN)/알람 처리, Control 결과는 환자 이력에서 분리

**안정성**: 스레드 안전(CopyOnWrite/스냅샷), CSV·설정 파일 원자적 저장(임시파일→교체), 재시작 후 이력 최신순, 로케일 독립 숫자 포맷, 설정 항목 하나가 깨져도 나머지 로드,
QC 기준값 검증(Min<Target<Max, K>0), 채널 전환 시 리스너 중복 제거, 포트 연결을 UI 스레드 밖에서 수행, 종료 시 정리

**UI**: STAT 체크 / ID 모드 체크 추가, QC·CAL 빠른 입력 제거(오더 불가), 프리셋 저장 시 선택 항목이 덮어써지던 버그 수정, 시약 표 선택 유지, HTML 이스케이프, 이벤트/경고 표시줄, 시뮬레이터용 "가상 QC1/QC2" 버튼

## 알아둘 점 (확인 필요)

1. **실제 장비/실제 COM 포트로는 테스트하지 못했습니다.** 시뮬레이터와 단위/통합 테스트로만 검증했습니다. 첫 연결 시 트레이스 창(📡)으로 ANY↔MOR 가 오가는지 확인하세요.
2. 매뉴얼 표가 깨져서 **추정한 부분**: Position 최대 35, Control 샘플의 Sample No. 필드(`공백2 + Control No. + Analyze Count 2자리`), 결과 FU 대/소문자(수신은 둘 다 허용). 다르면 `Hitachi3100Constants` / `SampleInfo` 한 곳만 고치면 됩니다.
3. 종료 코드는 **ETX+BCC 만** 지원합니다. 장비를 다른 종료 코드로 설정했다면 맞춰야 합니다.
4. Calibration(G1/G2/Hb)·흡광도 데이터는 수신하면 `MOR` 로 응답만 하고 저장하지 않습니다. RES(특정 검체 결과 요청)는 구현하지 않았습니다.
5. 탭 2 의 `K-Factor / Cal Conc` 는 화면 저장용이며 장비로 전송되지 않습니다 (Host→AU Calibration 설정 텍스트는 매뉴얼에 없음).
6. L-J 차트의 SD 는 여전히 `(Max-Min)/6` 추정입니다. 정식 QC 에는 제조사 SD 또는 누적 데이터 SD 를 쓰는 것이 맞아 정책 결정이 필요합니다.
7. 기존 `results.csv` 에 있는 옛 기록은 알람 열에 `H`/`L`(옛 방식의 High/Low)이 들어 있어, 열면 "Standard 1 이상" 같은 알람 설명으로 보일 수 있습니다. 판정(H/L)은 그대로입니다.
8. 이 개발 환경은 화면 없는 JRE 라서 `MainFrame` 창 자체는 띄워보지 못했고, 4개 탭 패널은 실제 서비스/시뮬레이터에 연결해 버튼 조작·렌더링까지 확인했습니다.
